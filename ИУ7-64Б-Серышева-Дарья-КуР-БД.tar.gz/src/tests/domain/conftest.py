from collections.abc import Callable
from uuid import UUID, uuid4

import pytest

from domain.entities import Card, Deck, Game, Image, Player, User
from domain.enums import DeckType, GameStatus


@pytest.fixture
def make_card() -> Callable[..., Card]:
    def _make_card(
        *,
        title: str = "Test card",
        creature: str = "test dwarf",
        power: int = 1,
        echo: int = 1,
        cost: int = 3,
        cool_points: int = 0,
        image_title: str = "Test image",
        image_file: str | None = "cards/test-card.png",
    ) -> Card:
        image = Image(id=uuid4(), title=image_title, file=image_file)
        return Card(
            id=uuid4(),
            title=title,
            creature=creature,
            card_type_id=uuid4(),
            image_id=image.id,
            power=power,
            echo=echo,
            cost=cost,
            cool_points=cool_points,
            image=image,
        )

    return _make_card


@pytest.fixture
def make_deck() -> Callable[..., Deck]:
    def _make_deck(
        *,
        type: DeckType = DeckType.DECK,
        if_open: bool = False,
        cards: list[Card] | None = None,
    ) -> Deck:
        return Deck(
            id=uuid4(),
            type=type,
            if_open=if_open,
            cards=cards or [],
        )

    return _make_deck


@pytest.fixture
def make_user() -> Callable[..., User]:
    def _make_user(
        username: str = "user",
    ) -> User:
        return User(
            id=uuid4(),
            username=username,
        )

    return _make_user


@pytest.fixture
def make_player(make_deck: Callable[..., Deck]) -> Callable[..., Player]:
    def _make_player(
        *,
        user_id: UUID | None = None,
        nickname: str = "player",
        turn_order: int = 0,
        health: int = 20,
        base_echo: int = 0,
        cur_echo: int = 0,
        hand_size: int = 5,
        draw_deck: Deck | None = None,
        hand_deck: Deck | None = None,
        table_deck: Deck | None = None,
        discard_deck: Deck | None = None,
    ) -> Player:
        return Player(
            id=uuid4(),
            user_id=user_id or uuid4(),
            nickname=nickname,
            turn_order=turn_order,
            health=health,
            base_echo=base_echo,
            cur_echo=cur_echo,
            hand_size=hand_size,
            draw_deck=draw_deck or make_deck(),
            hand_deck=hand_deck or make_deck(),
            table_deck=table_deck or make_deck(),
            discard_deck=discard_deck or make_deck(),
        )

    return _make_player


@pytest.fixture
def make_game(make_deck: Callable[..., Deck]) -> Callable[..., Game]:
    def _make_game(
        *,
        host_user_id: UUID,
        status: GameStatus = GameStatus.CREATED,
        players: list[Player] | None = None,
        cur_turn: int = 0,
        cur_player_id: UUID | None = None,
        winner_id: UUID | None = None,
        market_deck: Deck | None = None,
        game_deck: Deck | None = None,
        banish_deck: Deck | None = None,
        pending_attack: object | None = None,
    ) -> Game:
        return Game(
            id=uuid4(),
            host_user_id=host_user_id or uuid4(),
            status=status,
            players=players or [],
            cur_turn=cur_turn,
            cur_player_id=cur_player_id,
            winner_id=winner_id,
            market_deck=market_deck or make_deck(type=DeckType.DECK, if_open=True),
            game_deck=game_deck or make_deck(type=DeckType.DECK, if_open=False),
            banish_deck=banish_deck or make_deck(type=DeckType.DECK, if_open=False),
            pending_attack=pending_attack,
        )

    return _make_game
